"""
Utilidades auxiliares para el proyecto.
"""
